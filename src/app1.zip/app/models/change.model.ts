export class ChangePassword {
    constructor(
        public guid: string,
        public clave: string,
        public claveconf: string,
    ){}
}