export class Permisos {
    constructor(
        public OpcionesPerfilId: number,
        public PerfilId: number,
        public PerfilNombre: string,
        public OpcionId: number,
        public OpcionTitulo: string,
    ) { }
}