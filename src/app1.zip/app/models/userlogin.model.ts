export class UserLogin {
    constructor(
        public usuario: string,
        public password: string,
    ){}
}