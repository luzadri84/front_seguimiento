export class TiposEntidades {
    constructor(
        public tipId: number,
        public tipNombre: string,
        public vigId: number,
        public tipTipId: number,
        public tipNumeroProyectos: number,
        public fecCreo: string,
        public usuCreo: string 
    ){}
}