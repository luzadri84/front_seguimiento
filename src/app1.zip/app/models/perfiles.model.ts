export class Perfil {
    constructor(
        public perfilid: number,
        public perfilnombre: string,
        public perfiltipo: string,
        public perfilhabilitado: string,
    ) { }
}
