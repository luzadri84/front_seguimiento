export class Opcion {
    constructor(
        public OpcionId: number,
        public PerfilId: number,
    ) { }
}