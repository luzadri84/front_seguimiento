export class ForgotPassword {
    constructor(
        public usuario: string,
        public correo: string,
    ){}
}