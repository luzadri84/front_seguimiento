import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.compontent.html',
  styles: []
})
export class FooterComponent implements OnInit {
    constructor(){}
    ngOnInit(): void {
        
    }
}